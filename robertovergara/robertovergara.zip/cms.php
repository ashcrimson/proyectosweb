<!DOCTYPE html>
<html>
<body>
<form action="index.php" method="post">
	Titulo:<input type="text" name="titulo">
	Fecha:<input type="text" name="fecha">
	<textarea cols="40" rows="5" name="parrafo"></textarea>
	<input type="submit" value="Enviar">
</form>
</body>
</html>