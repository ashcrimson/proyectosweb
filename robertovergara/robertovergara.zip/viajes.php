<!DOCTYPE html>
<html lang="en">

<?php include('header.php');?>
	<div class="clearfix">
	<div class="row">
		<div class="col-sm-6" id="experiencia"id="experiencia">
		<img src="imagenes/italia.jpg">
		</div>
		<div class="col-sm-6" style="text-align:center;">
		<a href="#">Viaje a Italia</a>
		
		</div>
	</div>
	
	<div class="row">
		<div class="col-sm-6" id="experiencia"id="experiencia">
		<img src="imagenes/republica dominicana.jpg">
		</div>
		<div class="col-sm-6" id="experiencia"id="experiencia">
		<a href="#">Viaje a República Dominicana</a>
		</div>
	</div>
	<div class="row">
		<div class="col-sm-6" id="experiencia"id="experiencia">
		<img src="imagenes/panama.jpg">
		</div>
		<div class="col-sm-6" id="experiencia"id="experiencia">
		<a href="#">Ruta Panama-Colombia</a>
		</div>
	</div>
	
	<div class="row">
		<div class="col-sm-6" id="experiencia">
		<img src="imagenes/brasil.jpg">
		</div>
		<div class="col-sm-6" id="experiencia">
		<a href="#">Viajes a Brasil</a>
		
		</div>
	</div>
	<div class="row">
		<div class="col-sm-6" id="experiencia">
		<img src="imagenes/argentina.jpg">
		</div>
		<div class="col-sm-6" id="experiencia">
		<a href="#">Viaje a Argentina</a>
		
		</div>
</div>
	<div class="row">
		<div class="col-sm-6" id="experiencia">
		<img src="imagenes/cuba.jpg">
		</div>
		<div class="col-sm-6" id="experiencia">
		<a href="#">Viaje a Cuba</a>
		
		</div>
	</div>
	
	<br>
	<?php include'footer.php';?>