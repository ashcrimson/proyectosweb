<footer>
		<div class="row">
			<div class="col-sm-3" >
			<h1>Secciones de la Web</h1>
			<ul>
				<li>Inicio</li>
				<li>Experiencia</li>
				<li>Educación</li>
				<li>Cursos</li>
				<li>Aptitudes</li>
				<li>Viajes</li>
				<li>Anexos</li>
			</ul>
		</div>
		<div class="col-sm-3">
			<h1>Links de Interés</h1>
		</div>
		<div class="col-sm-3">
			<h1>Redes sociales</h1>
			
		</div>

		<div class="col-sm-3">
			<h1>Contacto</h1>
			
		</div>
	</div>

	</footer>
</div>
<script src="js/jquery-1.11.3.min.js"></script>
<script src="js/slider.js"></script>
</body>

</html>