<!DOCTYPE html>
<html lang="en">
<head>
	
		<?php include('header.php');?>
	<div class="clearfix">
	<div class="row">
		<div class="col-sm-6" id="experiencia">
		<img src="imagenes/shopping.jpg">
		</div>
		<div class="col-sm-6" id="experiencia">
		<a href="#">Congreso Internacional de Shopping Centers
Buenos Aires, Argentina</a>
		<p>2013 </p>
		
		</div>
	</div>
	
	<div class="row">
		<div class="col-sm-6" id="experiencia">
		<img src="imagenes/comercio.jpg">
		</div>
		<div class="col-sm-6" id="experiencia">
		<a href="#">Evaluación de Competencias Laborales
Sector Turismo
Cámara Regional de Comercio / SENCE</a>
		<p>2011</p>
		</div>
	</div>
	<div class="row">
		<div class="col-sm-6" id="experiencia">
		<img src="imagenes/santander.jpg">
		</div>
		<div class="col-sm-6" id="experiencia">
		<a href="#">Gestión Bancaria y Financiera
Centro Capacitación Banco Santander</a>
		<p>2010</p>
		</div>
	</div>
	
	<div class="row">
		<div class="col-sm-6" id="experiencia">
		<img src="imagenes/lachile.jpg">
		</div>
		<div class="col-sm-6" id="experiencia">
		<a href="#">Diplomado Gestión Retail
Universidad de Chile
Santiago</a>
		<p>2007</p>
		
		</div>
	</div>
	
	<br>
	<?php include'footer.php';?>