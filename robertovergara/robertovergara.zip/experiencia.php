<!DOCTYPE html>
<html lang="en">
<head>
	
		<?php include('header.php');?>
	<div class="clearfix">
	<div class="row">
		<div class="col-sm-6" id="experiencia">
		<img src="imagenes/arkon.jpg">
		</div>
		<div class="col-sm-6" id="experiencia">
		<a href="#">Gerente Comercial

Red de Apart Hoteles & Hostales de Inmobiliaria Arkon</a>
		<p>Enero 2010 − Presente (4 años 6 meses)</p>
		<p>Diseño, desarrollo y operación de una red de apart hoteles y hostales distribuidos en tres zonas de la V región: Valparaíso, Viña del Mar y Reñaca. Sumando un total de 48 habitaciones tipo estudio ( Primera Etapa ).</p>
		</div>
	</div>
	
	<div class="row">
		<div class="col-sm-6" id="experiencia">
		<img src="imagenes/ripley.jpg">
		</div>
		<div class="col-sm-6" id="experiencia">
		<a href="#">Subgerente de Operaciones 

Ripley</a>
		<p>Enero 2009 − Enero 2010 (1 año 1 mes)</p>
		<p>Responsable de coordinar y supervisar áreas que integran backoffice de una tienda RIPLEY a cargo de las siguientes áreas: personal, informática, mantención, control interno...</p>
		</div>
	</div>
	<div class="row">
		<div class="col-sm-6" id="experiencia">
		<img src="imagenes/renaca.jpg">
		</div>
		<div class="col-sm-6" id="experiencia">
		<a href="#">Center Manager

Mall Plaza Reñaca de Inmobiliaria Arkon</a>
		<p>Marzo 2003 − Diciembre 2008 (5 años 10 meses)</p>
		<p>Encargado de diseñar e implementar estrategia comercial y plan anual de marketing de Mall Plaza Reñaca, analizando y desarrollando mercados, productos y clientes, para sostener e incrementar flujo de clientes, cumplir con tasas de...</p>
		</div>
	</div>
	
	<div class="row">
		<div class="col-sm-6" id="experiencia">
		<img src="imagenes/laguna marina club.jpg">
		</div>
		<div class="col-sm-6" id="experiencia">
		<a href="#">Jefe de Promoción y Ventas 
Laguna Marina Club + Club Alto Mantagua
de Inmobiliaria Napoleón</a>
		<p>Diciembre 1996 – Marzo 2002 (5 años 4 meses)</p>
		
		</div>
	</div>
	
	<br>
	<?php include'footer.php';?>