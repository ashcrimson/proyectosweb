sliderInt = 1;
sliderNext = 2;

$(document).ready(function(){
	$("#slider > img#1").fadeIn(300);


})
