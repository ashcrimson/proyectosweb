<!DOCTYPE html>
<html lang="en">
<head>
	id="experiencia
		<?php include('header.php');?>
	<div class="clearfix">
	<div class="row">
		<div class="col-sm-6" id="experiencia">
		<img src="imagenes/comunicador.jpg">
		</div>
		<div class="col-sm-6" id="experiencia">
		<a href="#">Excelente Comunicador</a>
		<p>Gran capacidad para transmitir ideas y desarrollar proyectos. Habilidad que me acompaña desde nivel escolar, vida universitaria y en los distintos cargos de mi trayectoria laboral. </p>
		
		</div>
	</div>
	
	<div class="row">
		<div class="col-sm-6" id="experiencia">
		<img src="imagenes/leadership.jpg">
		</div>
		<div class="col-sm-6" id="experiencia">
		<a href="#">Leadership</a>
		<p>Habilidades innatas de liderazgo con las cuales siempre he logrado poder guiar equipos de trabajo a obtener metas propuestas en forma continua.</p>
		</div>
	</div>
	<div class="row">
		<div class="col-sm-6" id="experiencia">
		<img src="imagenes/orientacion.jpg">
		</div>
		<div class="col-sm-6" id="experiencia">
		<a href="#">Orientación a Resultados</a>
		<p>En una búsqueda permanente de los resultados, logrando siempre alcanzar metas propuestas en ámbito profesional y personal.
Planificando y coordinando siempre para que el siguiente paso resulte más eficiente.</p>
		</div>
	</div>
	
	<div class="row">
		<div class="col-sm-6" id="experiencia">
		<img src="imagenes/teamwork.jpg">
		</div>
		<div class="col-sm-6" id="experiencia">
		<a href="#">Teamwork</a>
		<p>En cada proyecto que me he embarcado siempre he apostado por trabajo en equipo, característica indispensable para no ver limitada mi capacidad de gestión.</p>
		
		</div>
	</div>
	
	<br>
	<?php include'footer.php';?>