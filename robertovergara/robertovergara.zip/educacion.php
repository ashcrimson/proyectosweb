<!DOCTYPE html>
<html lang="en">
<head>
	
		<?php include('header.php');?>
	<div class="clearfix">
	<div class="row">
		<div class="col-sm-6" id="experiencia"id="experiencia">
		<img src="imagenes/catolica.jpg">
		</div>
		<div class="col-sm-6" id="experiencia"id="experiencia">
		<a href="#">Master of Business Administration (MBA)
Pontificia Universidad Católica de Valparaíso
PUCV</a>
		<p>2013 – 2014</p>
		
		</div>
	</div>
	
	<div class="row">
		<div class="col-sm-6" id="experiencia"id="experiencia">
		<img src="imagenes/lachile.jpg">
		</div>
		<div class="col-sm-6" id="experiencia"id="experiencia">
		<a href="#"><a href="#">Diplomado, Gestión Retail Universidad de Chile</a></a>
		<p>2007</p>
		</div>
	</div>
	<div class="row">
		<div class="col-sm-6" id="experiencia"id="experiencia">
		<img src="imagenes/maritima.jpg">
		</div>
		<div class="col-sm-6" id="experiencia"id="experiencia">
		<a href="#">Ingeniería Comercial
Universidad Marítima - Armada de Chile</a>
		<p>1997 – 2002</p>
		</div>
	</div>
	
	<div class="row">
		<div class="col-sm-6" id="experiencia">
		<img src="imagenes/arturopratt.jpg">
		</div>
		<div class="col-sm-6" id="experiencia">
		<a href="#">Cadete Naval
Escuela Naval Arturo Prat</a>
		<p>1993</p>
		
		</div>
	</div>
	
	<br>
	<?php include'footer.php';?>