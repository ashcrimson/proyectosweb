<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>Documento sin título</title>

</head>

<body>

	<form action="pagina_resultados_act.php" method="GET">

		<label>Buscar: </label><input type="text" name="buscar"></input>

		<input type="submit" name="enviando" value="Dale!">
	</form>
</body>
</html>