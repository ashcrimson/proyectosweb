<footer>
	<div class="row">
		<div class="col-sm-12 col-md-4">
			<p>
<span style="font-weight:bold;">Hotel Plaza San Francisco</span><br>
Av. Libertador Bernardo O´Higgins 816<br>
Santiago, Chile<br>
<a href="mailto:reservas@plazasanfrancisco.cl?Subject=Hello%20again" target="_top">reservas@plazasanfrancisco.cl</a><br>
+56226393832 | +18553712979
</p>
		</div>
		<div class="col-sm-12 col-md-4">
			<img src="img/lereve-01.png.0x60.png"  >
			<img src="img/valle-nevado-5.jpg.0x60.jpg"  >
			<img src="img/firefly-4.jpg.0x60.jpg" >
		</div>

		<div class="col-sm-12 col-md-4">
			<ul>
				<li><a href="#">Mapa del Sitio</a></li>
				<li><a href="#">Políticas de Privacidad</a></li>
				<li><a href="#">Políticas de Reservas</a></li>
				<li><a href="#">Hoteles y Afiliados</a></li>
				<li><a href="#">Descargas</a></li>
				<li><a href="#">Facturas Electrónicas</a></li>
				<li><a href="#">Trabaja con nosotros</a></li>
				<li><a href="#">Alianzas</a></li>
			</ul>
		</div>
	</div>
</footer>
	<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.3/jquery.min.js"></script>
  	<script src="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.5/js/bootstrap.min.js"></script>
  	<script src="http://cdnjs.cloudflare.com/ajax/libs/modernizr/2.6.2/modernizr.min.js"></script>
</body>
</html>