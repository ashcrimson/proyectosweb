	<aside>
			<h1><a href="#">Habitaciones</a></h1>
			<ul >
        <li><a href="junior-suite.php">Junior Suite</a></li>
       	<li><a href="standard-twin.php">Standard Twin</a></li>
       	<li><a href="superior-king.php">Superior King</a></li>
        <li><a href="superior-twin.php">Superior Twin</a></li>
       	<li><a href="standard-king.php">Standard King</a></li>
       
      </ul>
       
      
			</aside>