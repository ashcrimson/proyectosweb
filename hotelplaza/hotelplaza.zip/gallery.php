<!DOCTYPE html>
	<html lang="es">
		<?php include('header.php');?>
		<!-- Trigger the modal with a button -->
  

	
		
		
		<?php include('footer.php');?>
	