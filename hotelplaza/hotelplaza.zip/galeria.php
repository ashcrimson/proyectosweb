<!DOCTYPE html>
	<html lang="es">
		<?php include('header.php');?>
		<!-- Trigger the modal with a button -->
  		<div class="row">
		<div class="col-sm-12 col-md-6" style="text-align:center;">
			<iframe width="709" height="429" src="GammaGallery/index.html" ></iframe>
		</div>
		<div class="col-sm-12 col-md-6" style="text-align:center;">
			<p>PENE</p>
		</div>
		</div>
	
		<?php include('footer.php');?>
	